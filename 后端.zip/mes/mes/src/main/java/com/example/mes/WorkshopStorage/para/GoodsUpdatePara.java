package com.example.mes.WorkshopStorage.para;

public class GoodsUpdatePara {
    private String storage_id;
    private String shelf_id;
    private String location;
    private String newStorage_id;
    private String newShelf_id;
    private String newLocation;

    public String getStorage_id() {
        return storage_id;
    }

    public void setStorage_id(String storage_id) {
        this.storage_id = storage_id;
    }

    public String getShelf_id() {
        return shelf_id;
    }

    public void setShelf_id(String shelf_id) {
        this.shelf_id = shelf_id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNewStorage_id() {
        return newStorage_id;
    }

    public void setNewStorage_id(String newStorage_id) {
        this.newStorage_id = newStorage_id;
    }

    public String getNewShelf_id() {
        return newShelf_id;
    }

    public void setNewShelf_id(String newShelf_id) {
        this.newShelf_id = newShelf_id;
    }

    public String getNewLocation() {
        return newLocation;
    }

    public void setNewLocation(String newLocation) {
        this.newLocation = newLocation;
    }
}
