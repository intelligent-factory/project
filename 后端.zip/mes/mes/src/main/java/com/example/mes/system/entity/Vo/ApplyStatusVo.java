package com.example.mes.system.entity.Vo;

import lombok.Data;

@Data
public class ApplyStatusVo {
    private String status;
    private Integer count;
}
