package com.example.mes.system.entity;

import lombok.Data;

@Data
public class Access {
    private Integer id;
    private String access_name;
    private String access_key;
}
