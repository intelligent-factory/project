package com.example.mes.system.entity.Vo;

import lombok.Data;

@Data
public class AccessGetVo {
    private Integer id;
}
