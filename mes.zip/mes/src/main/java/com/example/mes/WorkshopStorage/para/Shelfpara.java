package com.example.mes.WorkshopStorage.para;

public class Shelfpara {
    private String shelf_id;

    public String getShelf_id() {
        return shelf_id;
    }

    public void setShelf_id(String shelf_id) {
        this.shelf_id = shelf_id;
    }
}
