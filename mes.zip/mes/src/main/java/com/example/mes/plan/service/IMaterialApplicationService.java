package com.example.mes.plan.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.mes.plan.vo.MaterialApplicationVo;

public interface IMaterialApplicationService extends IService<MaterialApplicationVo> {

}
