package com.example.mes.system.entity.Vo;

import lombok.Data;

/**
 * @author tianfy
 * @date 2021-07-20
 */

@Data
public class LoginVo
{
    private String password;
    private String user_name;
}
