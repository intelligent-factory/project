package com.example.mes.system.entity.Vo;

import lombok.Data;

@Data
public class AccessVo {
    private Integer id;
    private String access_key;
}
